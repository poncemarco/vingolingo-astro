const t="http://localhost:8000";export{t as S};
